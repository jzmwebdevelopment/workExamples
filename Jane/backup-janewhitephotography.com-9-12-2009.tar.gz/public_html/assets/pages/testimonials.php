<h1>Testimonials</h1>

<p>Hi  Jane,<br/>

Sorry I haven't been in touch with you, But I must compliment you on what a great job you have done with our photos. See you soon.<br/>
Cheers <br/> Craig & Sharna  April 2009</p><br/><br/>

<p> 
Hey Jane,<br/>
Those photos are AMAZING!!<br/>
You did such an awesome job. Thank you so so much. We are blown away by how great they look.
We just wanted to say a big thank you and michelle for your work at our wedding on the 31st of Jan.
You were great to deal with, and we would not hesitate to recommend you to any one thats looking for a photographer.
<br/>
Brooke & Scott </p><br/><br/>

<p>Thanks Jane! I love them!!! <br/>

Cale & Maria</p><br/><br/>

<p>Hi Jane,<br/>
Thank you so much, we get lots of fabulous comments on our wedding photos, especially the one with the 4 boys cracking up.
<br/>
Rog & Chrissy
</p><br/><br/>
<p>Thank you so much for doing the photos the ones you have sent look amazing.
<br/>
Sarah & Troy</p><br/><br/>

<p>Everyone I have shown the web gallery to has said that the photo's are amazing. Thank you.
 <br/>
Tammy & Mike</p><br/><br/>

<p>
We were really impressed with the creative work you did to the last lot of pics and look forward to seeing the rest.
<br/>
Tina</p>
