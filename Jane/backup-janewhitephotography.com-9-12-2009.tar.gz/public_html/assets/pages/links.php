<h1>Links</h1>

<h2>General</h2>
<div id="links">
<a href="http://jzm.co.nz">JZM Webdesign</a><br/>
<a href="http://louisetreherne.weebly.com/">Louise Treherne Photography</a><br/>
<a href="http://www.dreamstime.com/">Dreamstime - High Resolution Stock Photography</a><br/>
<a href="http://picasa.google.com/">Picasa - The Easy Way To Find, Edit &amp; Share Your Photos</a><br/>
<a href="http://www.deviantart.com/">DeviantART - Where ART Meets Application</a><br/><br/>


<h2>Wedding Information Links</h2>

<br/>

<a href="http://www.weddingsguide.co.nz/">Wedding Guide New Zealand</a><br/>
<a href="http://weddings.co.nz/">Weddings.co.nz - New Zealand Wedding Magazine With Everything For The Future Bride &amp; Groom</a><br/>
<a href="http://www.weddingheaven.co.nz">Wedding Heaven - For Planning Weddings in New Zealand</a><br/>
<a href="http://www.weddingsolutions.co.nz/">Wedding Solutions</a><br/>
<a href="http://www.nz-wedding.co.nz/">NZ Wedding - New Zealand's Online Wedding Directory</a><br/>
<a href="http://www.nzweddingplanner.co.nz/">New Zealand Wedding Planner</a><br/>
<a href="http://www.do-it-yourself-weddings.com/">The Do It Yourself Weddings Guide</a><br/>
<a href="http://www.best-wedding-plan.com/">The Do It Yourself Weddings Plan</a><br/>
<a href="http://www.wedding-info.co.nz/">Wedding Info NZ</a><br/>
<a href="http://www.aaronbloomfield.com">Aaron Bloomfield - Celebrant</a><br/>
<a href="http://www.nzbeachweddings.com">New Zealand Beach Weddings</a><br/>
<a href="http://www.funtasiaevents.co.nz">Tauranga's Leading Events Decorating Companys</a><br/>
<a href="http://www.mctours.co.nz">Mount Classics New Zealand and Australia Shore Trips and Tours Wedding Cars Limousines</a>
</div>