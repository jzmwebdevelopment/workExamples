<h1>Pricing &amp; Info</h1>

<p><strong>Pricing &amp; Info</strong>

 

I work with 2 x Nikon DSLR cameras, various photography equipment &amp; props &amp; shoot in Raw format. For weddings &amp; large requirement shoots I have a photographers assistant whom handles equipment, props and other essentials.<br/><br/>

 
<strong>Wedding Photography</strong><br/><br/>

 

Because every wedding is different and unique, some large, some small, some are second weddings; I prefer to work with the couple to tailor an individual wedding photography package to meet their requirements and expectations. Please contact me with your details and allow me to work with you to create a custom-made package.<br/><br/>

 

Below however is an all-encompassing package consisting of wedding coverage, hi res images ready for you to print, Wedding Album Photo Book, online photo gallery.<br/><br/>

<strong>Classic Package</strong><br/><br/>
Coverage includes:
<ul>
<li>Bride preparations</li>
<li>Bride arriving</li>
<li>Ceremony</li>
<li>Group Shot &amp;amp; Family formals</li>
<li>Location</li>
<li>Bride and groom arriving</li>
<li>Reception mock cutting cake</li>
<li>Reception detail shots</li>
</ul>

 

Approx 5 hours of continuous coverage by photographer &amp; photographer's assistant.<br/><br/>

All hi res ready to print photos supplied on DVD or USB memory stick in .jpeg format.<br/><br/>

All images edited and enhanced, b&amp;w &amp; colour.  Approx 400+ images.<br/><br/>

Private unlisted online web gallery.<br/><br/>

20-page Wedding Album Photo book <br/><br/>

 

<strong>$1,950.00 Gst Incl</strong> <br/><br/>

Please contact me for full details of package.
All other photography quoted by scope of work, Retouching, design work &amp; photo manipulation priced by hourly rate.
</p>